==================================================
Django Request-Response and Model Change Logger
==================================================

Django REST framework logger is an application to log requests/responses and model changes to the database.

Quick Start
==============

1. Add drf_request_logger to your project just like the following::
    INSTALLED_APPS = [
        ......
        "drf_request_logger"
    ]
